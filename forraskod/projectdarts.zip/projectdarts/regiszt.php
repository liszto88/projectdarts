<?php
//include_once "kod.php";
//require_once "kod.php";
session_start();

$email = $_POST["email"];
$nicknev = $_POST["nickname"];
$jelszo = $_POST["password"];
$nem = $_POST["gender"];
$nem = ($nem === 'nő') ? 'n' : 'f';
$szul_ido = $_POST["birthDate"];

//   !!!!!!!!!!!!!KÖTELEZŐ - ellenőrizni BackEnd oldalon is!!!!!!!!!!!!
//pl.:
//if ($nicknev == "")
    {
        //hiba feldolgozása, ÉS abbahagyod a regisztrációt! (Ha nem tudod automatikusan javítani.)
    }

$servername = "localhost";
$username = "root"; // Módosítsd az adatbázis felhasználónévnek megfelelően
$password = ""; // Módosítsd az adatbázis jelszónak megfelelően
$dbname = "darts";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Kapcsolódási hiba: " . $conn->connect_error);
}   

/*
insert into felhasznalok
VALUES
('Anna@bal.hu', 'Anna', md5('Anna_jelszava'), 'n', '2003-08-09', 'Pécs', 'r', NULL)
*/

// felhasználó mentése adatbázisba
$stmt = $conn->prepare("insert into felhasznalok VALUES (?, ?, md5(?), ?, ?, 'r', NULL);");
$stmt->bind_param("sssss", $email, $nicknev, $jelszo, $nem, $szul_ido);
//s -> string
//i -> int
//d -> double
//b -> blob (binary large object)
$ok = $stmt->execute();   // itt lefuttatjuk, és visszaadja true/false-t
$errorMsg = $stmt->error; // ha hiba volt, itt van az üzenet


//$kod = kod_generalas();

/*insert into validalas VALUES ('Vki@vmi.hu', date_add(now(), interval 1 day), 'kdshfjahds', null);*/

// az email validálása
//$stmt = $conn->prepare("insert into validalas VALUES (?, date_add(now(), interval 1 day), ?, null);");
//$stmt->bind_param("ss", $email, $kod);
//s -> string
//i -> int
//d -> double
//b -> blob (binary large object)
//$stmt->execute();  

/*
$leveltorzs = "Tisztelt XY!\r\n";
$leveltorzs .= "Az alábbi linkre kattintva erősítheti meg...";
$leveltorzs .= "http://nagyonokosvagyok.hu/17_alkalom/validalas.php?kod=.......",
$leveltorzs .= "<a href=\"http://nagyonokosvagyok.hu/17_alkalom/validalas.php?kod=.......\"link</a>";


mail($email, "Validálás", $leveltorzs);
*/

//echo "<a href=\"http://127.0.0.1/17_alkalom/validalas.php?email=" . $email .  "&kod=" .$kod . "\"> Validáláshoz kattintson ide!</a>";

//header("Location: belepes.php");

$stmt->close();
$conn->close();

// FLASH jelzők beállítása
if ($ok) {
    $_SESSION['reg_success'] = true;
} else {
    $_SESSION['reg_error'] = "Sikertelen regisztráció: " . $errorMsg;
}

header('Location: regisztracio.php');
exit;

?>