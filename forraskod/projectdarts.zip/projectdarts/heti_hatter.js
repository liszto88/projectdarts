// Háttérképek napok szerint
        const backgrounds = {
        0: 'hatter/heti0.jpg',     // Vasárnap
        1: 'hatter/heti1.jpg',     // Hétfő
        2: 'hatter/heti2.jpg',    // Kedd
        3: 'hatter/heti3.jpg',  // Szerda
        4: 'hatter/heti4.jpg',   // Csütörtök
        5: 'hatter/heti5.jpg',     // Péntek
        6: 'hatter/heti6.png'    // Szombat
        };

        function setBackground() {
        const today = new Date();
        const day = today.getDay(); // 0 = vasárnap, 1 = hétfő, ..., 6 = szombat
        document.body.style.backgroundImage = `url('${backgrounds[day]}')`;
        }

        setBackground();

        // Ellenőrzés minden percnél, hogy éjfél van-e
        setInterval(() => {
        const now = new Date();
        if (now.getHours() === 0 && now.getMinutes() === 0) {
            setBackground();
        }
        }, 60000); // 60 másodpercenként ellenőrzés