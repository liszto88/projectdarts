<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Darts Számoló</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Comic+Relief:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style1.css">
    <style>

        .tartalom 
        {   
        font-family: Comic Relief;
        font-weight: bold;
        width: 90%;               /* nagyobb szélesség */
        max-width: 600px;        /* max méret monitoron */
        min-height: 600px;        /* nagyobb alapmagasság */
        padding: 50px;            /* tágasabb belső tér */
        font-size: 1.2rem;        /* nagyobb szöveg alapból */

        display: flex;
        flex-direction: column;
        justify-content: center;
        flex-wrap: wrap;
        gap: 5px;

        margin: 40px auto;
        background-color: rgba(255, 255, 255, 0.6);
        border-radius: 16px;
        text-align: center;
        box-shadow: 0 6px 20px rgba(0, 0, 0, 0.25);
        backdrop-filter: blur(8px);
        }

        label 
        {
            margin-top: 10px;
            font-weight: bold;
        } 

        input
        {
            padding: 8px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

            .bej_button
        {   font-family: Comic Relief;
            font-weight: bold;
            margin-top: 15px;
            padding: 10px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

            .bej_button:hover
        {
            background-color: #0056b3;
        }

        @media (max-width: 768px) {
          .tartalom {
            width: 80%;
            padding: 20px;
          }
        }

        @media (max-width: 480px) {
          .tartalom {
            width: 90%;
            padding: 15px;
          }
        }
        
    </style>
</head>
<body>
    <div class="menusor">

        <?php if (isset($_SESSION["email"])): ?>
            <!-- Ha be van jelentkezve -->
            <button onclick="window.location.href='kijelentkezes.php'">Kijelentkezés</button>
        <?php else: ?>
            <!-- Ha nincs bejelentkezve -->
            <button onclick="window.location.href='bejelentkezesoldal.php'">Bejelentkezés</button>
        <?php endif; ?>
        <button onclick="window.location.href='regisztracio.php'">Regisztráció</button>
        <button onclick="window.location.href='jatek.php'">Játék!</button>
        <button onclick="window.location.href='index.php'">Főoldal</button>
        <button onclick="window.location.href='adartsrol.php'">A Dartsról</button>
        <button onclick="window.location.href='bemutatkozas.php'">Bemutatkozás</button>
    </div>

    <form class="tartalom" id="form" method="post" action="bejelentkezes.php">

    <div id="hiba_ablak"></div>

      <label for="email">Email cím</label>
      <input type="email" id="email" name="email" placeholder="Írd be az email címed!" required>

      <label for="password">Jelszó</label>
      <input type="password" id="password" name="password" placeholder="Írd be a jelszavad!" required>

    <button class="bej_button" type="submit">Bejelentkezés</button>

  </form>

    <script src="heti_hatter.js"></script>
    
</body>
</html>