<?php
session_start(); // munkamenet indítása (hogy be lehessen jelentkeztetni)

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = $_POST["email"];
    $jelszo = $_POST["password"];

    // Adatbázis kapcsolat
    $servername = "localhost";
    $username = "root";
    $password = ""; 
    $dbname = "darts";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Kapcsolódási hiba: " . $conn->connect_error);
    }

    // Felhasználó ellenőrzése
    $stmt = $conn->prepare("SELECT email, nicknev, jelszo, nem FROM felhasznalok WHERE email = ? AND jelszo = md5(?) LIMIT 1");
    $stmt->bind_param("ss", $email, $jelszo);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        // sikeres belépés
        $row = $result->fetch_assoc();

        // Session változók beállítása
        $_SESSION["email"] = $row["email"];
        $_SESSION["nicknev"] = $row["nicknev"];
        $_SESSION["nem"] = $row["nem"];

        // Átirányítás a főoldalra (vagy játékhoz)
        header("Location: index.php");
        exit();
    } else {
        // Sikertelen belépés
        echo "<script>alert('Hibás email cím vagy jelszó!'); window.location.href='bejelentkezes.html';</script>";
    }

    $stmt->close();
    $conn->close();
} else {
    header("Location: bejelentkezes.html");
    exit();
}
?>