<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Darts Számoló</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Comic+Relief:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style1.css">
    <style>
        #typewriter {
          font-family: 'Comic Relief', cursive;
          font-size: 2rem;
          white-space: wrap;
          word-wrap: break-word;
          text-align: center;
          padding: 50px;
          max-width: 800px;
          margin: 40px auto;
          width: 90%;

          /* animáció */
          opacity: 0;
          animation: fadeIn 1.5s ease-in forwards;
        }

        @keyframes fadeIn {
          from { opacity: 0; }
          to { opacity: 20; }
        }

        .tartalom {
          width: 90%;
          max-width: 1200px;
          min-height: 600px;
          padding: 50px;
          font-size: 1.2rem;

          display: flex;
          flex-direction: column;
          justify-content: center;
          flex-wrap: wrap;
          gap: 50px;

          margin: 0 auto;
          background-color: rgba(255, 255, 255, 0.6);
          border-radius: 16px;
          text-align: center;
          box-shadow: 0 6px 20px rgba(0, 0, 0, 0.25);
          backdrop-filter: blur(8px);
        }

        @media (max-width: 768px) {
          .tartalom {
            width: 80%;
            padding: 20px;
          }
        }

        @media (max-width: 480px) {
          .tartalom {
            width: 90%;
            padding: 15px;
          }
        }
    </style>
</head>
<body>
    <div class="menusor">
        <?php if (isset($_SESSION["email"])): ?>
            <!-- Ha be van jelentkezve -->
            <button onclick="window.location.href='kijelentkezes.php'">Kijelentkezés</button>
        <?php else: ?>
            <!-- Ha nincs bejelentkezve -->
            <button onclick="window.location.href='bejelentkezesoldal.php'">Bejelentkezés</button>
        <?php endif; ?>
        <button onclick="window.location.href='regisztracio.php'">Regisztráció</button>
        <button onclick="window.location.href='jatek.php'">Játék!</button>
        <button onclick="window.location.href='index.php'">Főoldal</button>
        <button onclick="window.location.href='adartsrol.php'">A Dartsról</button>
        <button onclick="window.location.href='bemutatkozas.php'">Bemutatkozás</button>
    </div>

    <div class="tartalom" id="typewriter">
      Üdvözöllek a darts világában! Nevem Lisztóczki Csaba és ez az én első projektmunkám. 
      Egy pár gondolat az oldalról. Az oldal segít neked a pontszámok nyilvántartásában, 
      követheted a saját vagy barátaid játékát, és megismerhetsz néhány szabályt is. 
      501 Double Out ami azt jelenti, hogy 501-ről indulva el kell érj pontosan a 0-ra 
      és csak dupla kiszállóval érheted el.  
      Kezdéshez válaszd a "Játék!" menüpontot. Sok sikert, és jó szórakozást! 🎯
    </div>

    <script src="heti_hatter.js"></script>
</body>
</html>