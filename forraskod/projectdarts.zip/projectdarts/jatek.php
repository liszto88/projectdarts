<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Darts Számoló</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Comic+Relief:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style1.css">
    <style>

    .tartalom 
        {
        font-family: Comic Relief;
        font-weight: bold;
        width: 90%;               /* nagyobb szélesség */
        max-width: 600px;        /* max méret monitoron */
        min-height: 600px;        /* nagyobb alapmagasság */
        padding: 50px;            /* tágasabb belső tér */
        font-size: 1.2rem;        /* nagyobb szöveg alapból */

        display: flex;
        flex-direction: column;
        justify-content: center;
        flex-wrap: wrap;
        gap: 5px;

        margin: 40px auto;
        background-color: rgba(255, 255, 255, 0.6);
        border-radius: 16px;
        text-align: center;
        align-items: center;
        box-shadow: 0 6px 20px rgba(0, 0, 0, 0.25);
        backdrop-filter: blur(8px);
      }
      
        @media (max-width: 768px)
      {
        .tartalom
        {
        width: 80%;
        padding: 20px;
        }
      }

        @media (max-width: 480px)
      {
        .tartalom
        {
        width: 90%;
        padding: 15px;
        }
    }

        .jatek_button {
        font-family: "Comic Relief", sans-serif;
        font-weight: bold;
        font-size: 1.5rem;
        padding: 20px;
        margin: 15px 0;
        width: 80%;
        max-width: 400px;
        background-color: #007bff;
        color: white;
        border: none;
        border-radius: 12px;
        cursor: pointer;
        box-shadow: 0 4px 12px rgba(0,0,0,0.2);
        transition: background-color 0.3s ease, transform 0.2s ease;
    }

        .jatek_button:hover {
        background-color: #0056b3;
        transform: translateY(-3px);
    }

    </style>
</head>
<body>
    <div class="menusor">

        <?php if (isset($_SESSION["email"])): ?>
            <!-- Ha be van jelentkezve -->
            <button onclick="window.location.href='kijelentkezes.php'">Kijelentkezés</button>
        <?php else: ?>
            <!-- Ha nincs bejelentkezve -->
            <button onclick="window.location.href='bejelentkezesoldal.php'">Bejelentkezés</button>
        <?php endif; ?>
        <button onclick="window.location.href='regisztracio.php'">Regisztráció</button>
        <button onclick="window.location.href='jatek.php'">Játék!</button>
        <button onclick="window.location.href='index.php'">Főoldal</button>
        <button onclick="window.location.href='adartsrol.php'">A Dartsról</button>
        <button onclick="window.location.href='bemutatkozas.php'">Bemutatkozás</button>
    </div>
    <div class="tartalom">

        <button class="jatek_button" onclick="window.location.href='egyjatekos.html'">
        1 játékos mód
    </button>

    <button class="jatek_button" onclick="inditKettoJatekos()">
        2 játékos mód
    </button>

    <script>
        function inditKettoJatekos() {
        const bejelentkezve = <?php echo isset($_SESSION['email']) ? 'true' : 'false'; ?>;

        if (bejelentkezve) {
            let j2 = prompt("2. játékos neve:");
            if (j2 && j2.trim() !== "") {
                window.location.href = "ketjatekos.php?j2=" + encodeURIComponent(j2);
            }
        } else {
            let j1 = prompt("1. játékos neve:");
            let j2 = prompt("2. játékos neve:");
            if (j1 && j2 && j1.trim() !== "" && j2.trim() !== "") {
                window.location.href = "ketjatekos.php?j1=" + encodeURIComponent(j1) + "&j2=" + encodeURIComponent(j2);
            }
        }
    }
    </script>

    </div>
    

    <script src="heti_hatter.js"></script>

</body>
</html>