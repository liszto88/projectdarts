function hiba(hibaszoveg)
{
    var tartalom_doboz = document.getElementById("hiba_ablak");
    tartalom_doboz.innerHTML = hibaszoveg;
    tartalom_doboz.innerHTML += "<br><br>";
    tartalom_doboz.innerHTML += "<input type=\"button\" onclick=\"bezar()\" value=\"Bezár\">";
    document.getElementById("hiba_ablak").style.display = "block";
}    

function bezar()
{
    var tartalom_doboz = document.getElementById("hiba_ablak");    
    document.getElementById("hiba_ablak").style.display = "none";
}