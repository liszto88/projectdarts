<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Darts Számoló</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Comic+Relief:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style1.css">

    <style>

        .tartalom {
          width: 90%;
          max-width: 1200px;
          min-height: 600px;
          padding: 50px;
          font-size: 1.2rem;

          display: flex;
          flex-direction: column;
          justify-content: center;
          flex-wrap: wrap;
          gap: 50px;

          margin: 0 auto;
          background-color: rgba(255, 255, 255, 0.6);
          border-radius: 16px;
          text-align: center;
          box-shadow: 0 6px 20px rgba(0, 0, 0, 0.25);
          backdrop-filter: blur(8px);
        }

        @media (max-width: 768px) {
          .tartalom {
            width: 80%;
            padding: 20px;
          }
        }

        @media (max-width: 480px) {
          .tartalom {
            width: 90%;
            padding: 15px;
          }
        }

#doboz2 {
  display: flex;
  flex-direction: column;
  gap: 20px;
  align-items: stretch;
}

#doboz2 h2 {
  text-align: center;
  margin-bottom: 20px;
}

.link-card {
  display: flex;
  align-items: center;
  gap: 20px;
  background: rgba(255,255,255,0.8);
  padding: 15px;
  border-radius: 12px;
  box-shadow: 0 4px 12px rgba(0,0,0,0.15);
  transition: transform 0.2s ease;
  flex-wrap: wrap; /* ha kisebb képernyőn nem fér ki egysorban, akkor törik */
}

.link-card:hover {
  transform: scale(1.02);
}

.link-card img {
  max-width: 120px;   /* a kép nem lesz nagyobb 120px-nél */
  width: 100%;        /* de kisebb képernyőn összemegy */
  height: auto;       /* arányosan skálázódik */
  border-radius: 8px;
  object-fit: cover;
}

.link-card h3 {
  margin: 0 0 8px 0;
  font-size: 1.3rem;
  color: darkred;
}

.link-card a {
  color: navy;
  text-decoration: none;
  font-weight: bold;
}

.link-card a:hover {
  text-decoration: underline;
}

/* Mobilbarát elrendezés */
@media (max-width: 600px) {
  .link-card {
    flex-direction: column; /* kép felül, szöveg alul */
    text-align: center;
  }

  .link-card img {
    max-width: 100%; /* mobilon a kép teljes szélességet kitölti */
  }
}

#doboz1 h2 {
  font-size: 1.8rem;       /* kisebb cím */
  margin-bottom: 15px;      /* kevesebb tér a cím alatt */
  color: darkred;
}

#doboz1 h3 {
  font-size: 1.4rem;        /* kisebb alcímek */
  margin-bottom: 10px;
}

#doboz1 p {
  font-size: 1rem;           /* kisebb szöveg */
  line-height: 1.4;          /* kisebb sorok közötti tér */
  text-align: left;
  max-width: 800px;
  margin: 0 auto 15px auto;  /* kevesebb alatti tér */
}

#doboz1 ul {
  font-size: 1rem;
  line-height: 1.4;
  margin: 0 auto 15px auto;
  padding-left: 20px;
}

    </style>
</head>
<body>
    <div class="menusor">

        <?php if (isset($_SESSION["email"])): ?>
            <!-- Ha be van jelentkezve -->
            <button onclick="window.location.href='kijelentkezes.php'">Kijelentkezés</button>
        <?php else: ?>
            <!-- Ha nincs bejelentkezve -->
            <button onclick="window.location.href='bejelentkezesoldal.php'">Bejelentkezés</button>
        <?php endif; ?>
        <button onclick="window.location.href='regisztracio.php'">Regisztráció</button>
        <button onclick="window.location.href='jatek.php'">Játék!</button>
        <button onclick="window.location.href='index.php'">Főoldal</button>
        <button onclick="window.location.href='adartsrol.php'">A Dartsról</button>
        <button onclick="window.location.href='bemutatkozas.php'">Bemutatkozás</button>
    </div>
    <div class="tartalom">

        <div class="tartalom" id="doboz2">
                <h2>Hasznos linkek</h2>

    <div class="link-card">
        <img src="hatter/pdchun.jpg" alt="PDC Hungarian Fan Club">
        <div>
            <h3>PDC Hungarian Fan Club</h3>
            <a href="https://www.facebook.com/pdchungarianfanclub?locale=hu_HU" target="_blank">
                Facebook oldal megnyitása
            </a>
        </div>
    </div>

    <div class="link-card">
        <img src="hatter/mdsz.jpg" alt="Magyar Darts Szövetség">
        <div>
            <h3>Magyar Darts Szövetség</h3>
            <a href="https://www.mdsz.hu/" target="_blank">
                Hivatalos oldal
            </a>
        </div>
    </div>

    <div class="link-card">
        <img src="hatter/pdctv.jpg" alt="Professional Darts Corporation">
        <div>
            <h3>Professional Darts Corporation</h3>
            <a href="https://www.pdc.tv/" target="_blank">
                Hivatalos oldal
            </a>
        </div>
    </div>

    <div class="link-card">
        <img src="hatter/gamecenter.jpg" alt="Gamecenter">
        <div>
            <h3>Gamecenter</h3>
            <a href="https://www.gamecenter.hu/" target="_blank">
                Webshop megnyitása
            </a>
        </div>
    </div>

    <div class="link-card">
        <img src="hatter/dartsbarlang.jpg" alt="Dartsbarlang">
        <div>
            <h3>Dartsbarlang</h3>
            <a href="https://dartsbarlang.hu/" target="_blank">
                Webshop megnyitása
            </a>
        </div>
    </div>

        </div>
         <div class="tartalom" id="doboz1">
                <h2>Játékszabály</h2>
    <p>
        A darts egyik legnépszerűbb és legismertebb játékmódja az 
        <strong>501 Double Out</strong>. A játék lényege, hogy minden játékos
        <strong>501 ponttal</strong> indul, és a cél az, hogy pontosan <strong>0-ra</strong> 
        dobja le magát.
    </p>

    <h3>Kezdés</h3>
    <p>
        A kezdő játékost általában sorsolással vagy egy előzetes "bull-dobással" 
        határozzák meg: aki közelebb dob a tábla közepéhez (bull), az kezd.
    </p>

    <h3>Játékmenet</h3>
    <p>
        Egy körben minden játékos <strong>három nyíllal</strong> dobhat. A dobott pontokat 
        levonják a játékos aktuális pontszámából. A számolás mindig a kezdő 
        501-ről indul.
    </p>
    <p>
        A dobások értéke a tábla szektorainak megfelelően alakul:
        <ul>
            <li><strong>Egyszeres szektor</strong>: az adott szám értéke (pl. 20 = 20 pont).</li>
            <li><strong>Dupla szektor</strong>: kétszeres érték (pl. dupla 20 = 40 pont).</li>
            <li><strong>Tripla szektor</strong>: háromszoros érték (pl. tripla 20 = 60 pont).</li>
            <li><strong>Bull</strong>: 25 pont.</li>
            <li><strong>Dupla bull</strong>: 50 pont.</li>
        </ul>
    </p>

    <h3>Kiszállás</h3>
    <p>
        A játékot csak akkor lehet megnyerni, ha a játékos pontosan <strong>0-ra</strong> 
        dobja magát, és az utolsó dobása <strong>dupla</strong> volt.  
        Ez az ún. <em>Double Out</em> szabály.
    </p>
    <p>
        Például, ha egy játékosnak 40 pontja marad, akkor a <strong>dupla 20</strong>-at kell 
        eltalálnia a győzelemhez.
    </p>

    <h3>Leg és meccs</h3>
    <p>
        Egy teljes játékmenetet <strong>legnek</strong> nevezünk. A mérkőzést 
        az a játékos nyeri, aki először megszerez <strong>3 leget</strong>.  
        A legtöbb versenyen ez az alapbeállítás (best of 5 leg).
    </p>

    <h3>Alapvető szabályok</h3>
    <ul>
        <li>A játékos lábának a dobás során a dobóvonal mögött kell maradnia.</li>
        <li>Ha a nyíl kipattan vagy kiesik a táblából, az a dobás érvénytelen.</li>
        <li>Csak a táblában bent maradó nyíl számít pontnak.</li>
        <li>Ha a játékos többet dob, mint amennyi pontja maradt, az adott kör érvénytelen, 
            és a pontszáma nem változik.</li>
    </ul>

    <h3>Győzelem</h3>
    <p>
        A győztes az a játékos, aki először nyeri meg a kiírt számú leget 
        (például <strong>3 nyert legig</strong> tartó mérkőzésben az, aki elsőként ér el 3 győzelmet).
    </p>
        </div>
        <div class="tartalom" id="doboz3">

        </div>
        <div class="tartalom" id="doboz4">

        </div>



    </div>

    

    <script src="heti_hatter.js"></script>
</body>
</html>