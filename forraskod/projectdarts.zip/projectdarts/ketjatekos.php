<?php
session_start();

// ha be van jelentkezve, a DB-ből lekérjük a nicknevét
$nick = "";
if (isset($_SESSION["email"])) {
    $conn = new mysqli("localhost", "root", "", "darts");
    if (!$conn->connect_error) {
        $stmt = $conn->prepare("SELECT nicknev FROM felhasznalok WHERE email=?");
        $stmt->bind_param("s", $_SESSION["email"]);
        $stmt->execute();
        $stmt->bind_result($nick);
        $stmt->fetch();
        $stmt->close();
        $conn->close();
    }
}

// ha nincs bejelentkezve, akkor az URL-ből jön mindkét név
$j1 = isset($_GET['j1']) ? $_GET['j1'] : $nick;
$j2 = isset($_GET['j2']) ? $_GET['j2'] : "";
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Darts Számoló</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Comic+Relief:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="style1.css">
    <style>

        .tartalom {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            gap: 40px;

            width: 100%;           /* teljes szélesség */
            max-width: 800px;      /* maximum szélesség */
            margin: 0 auto;
            padding: 20px;
            background-color: rgba(255, 255, 255, 0.6);
            border-radius: 12px;
            text-align: center;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
            box-sizing: border-box; /* padding + border bele számít a szélességbe */
        }

        #szamok {
            display: grid;
            grid-template-columns: repeat(3, 1fr); /* fix 3 oszlop */
            grid-template-rows: repeat(4, 1fr);    /* fix 4 sor */
            gap: 10px;
            width: 100%;
            padding: 0; /* ne növelje a szélességet a padding */
            box-sizing: border-box;
        }

        .doboz {
            display: flex;
            justify-content: center;
            align-items: center;
            background: rgb(119, 119, 119);
            border: 2px solid #333;
            border-radius: 5px;
            width: 100%;
            height: 100%;
            box-sizing: border-box;
        }

        .doboz button {
            font-family: Comic Relief;
            font-size: clamp(16px, 3vw, 28px);
            font-weight: bold;
            width: 90%;
            height: 90%;
            border-radius: 5px;
            border: none;
            background-color: #007bff;
            color: black;
            cursor: pointer;

            /* Új rész: box shadow */
            box-shadow: 0 4px 8px rgba(0,0,0,0.3); /* enyhe árnyék */
            transition: 0.2s, box-shadow 0.2s;
        }

        .doboz button:hover {
            background-color: #0056b3;
            transform: scale(1.05);
            box-shadow: 0 8px 16px rgba(0,0,0,0.4); /* kicsit erősebb hoverre */
        }

        @media (max-width: 768px)
        {
            .tartalom
            {
            width: 80%;
            padding: 20px;
            }
        }

        @media (max-width: 480px)
        {
            .tartalom
            {
            width: 90%;
            padding: 15px;
            }
        }

        /* #kiszallok konténer */
        #kiszallok {
            display: grid;
            grid-template-columns: repeat(2, 1fr); /* 2 oszlop */
            grid-template-rows: 1fr;                /* 1 sor */
            gap: 15px;                              /* távolság a dobozok között */
            width: 100%;
            padding: 0;
            box-sizing: border-box;
        }

        .kiszallok_doboz {
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: #f0f0f0;
            border: 2px solid #333;
            border-radius: 5px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.2);
            font-family: Comic Relief;
            font-size: clamp(16px, 3vw, 28px);  /* reszponzív betűméret */
            font-weight: bold;
            color: #333;
            width: 100%;
            height: 100%;
        }

        #pontok {
            display: grid;
            grid-template-columns: repeat(2, 1fr); /* 2 oszlop */
            grid-template-rows: 1fr;                /* 1 sor */
            gap: 15px;                              /* távolság a dobozok között */
            width: 100%;
            padding: 0;
            box-sizing: border-box;
        }

        .pont_doboz {
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: #f0f0f0;
            border: 2px solid #333;
            border-radius: 5px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.2);
            font-family: Comic Relief;
            font-size: clamp(16px, 3vw, 28px);  /* reszponzív betűméret */
            font-weight: bold;
            color: #333;
            width: 100%;
            height: 100%;
        }

        #legek {
            display: grid;
            grid-template-columns: repeat(2, 1fr); /* 2 oszlop */
            grid-template-rows: 1fr;                /* 1 sor */
            gap: 15px;                              /* távolság a dobozok között */
            width: 100%;
            padding: 0;
            box-sizing: border-box;
        }

        .legek_doboz {
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: #f0f0f0;
            border: 2px solid #333;
            border-radius: 5px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.2);
            font-family: Comic Relief;
            font-size: clamp(16px, 3vw, 28px);  /* reszponzív betűméret */
            font-weight: bold;
            color: #333;
            width: 100%;
            height: 100%;
        }

        #nevek {
            display: grid;
            grid-template-columns: repeat(2, 1fr); /* 2 oszlop */
            grid-template-rows: 1fr;                /* 1 sor */
            gap: 15px;                              /* távolság a dobozok között */
            width: 100%;
            padding: 0;
            box-sizing: border-box;
        }

        .nevek_doboz {
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: #f0f0f0;
            border: 2px solid #333;
            border-radius: 5px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.2);
            font-family: Comic Relief;
            font-size: clamp(16px, 3vw, 28px);  /* reszponzív betűméret */
            font-weight: bold;
            color: #333;
            width: 100%;
            height: 100%;
        }

        #uzenet {
            display: grid;
            grid-template-columns: 1fr;  /* 1 oszlop */
            grid-template-rows: 1fr;     /* 1 sor */
            width: 100%;
            gap: 0;
            padding: 0;
            box-sizing: border-box;
        }

        .uzenet_doboz {
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: #f0f0f0;
            border: 2px solid #333;
            border-radius: 5px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.2);
            font-family: Comic Relief;
            font-size: clamp(16px, 3vw, 28px);  /* reszponzív betűméret */
            font-weight: bold;
            color: #333;
            width: 100%;
            height: 100%;  /* így a magasság megegyezik a szülő gridcellával */
        }

    </style>
</head>
<body>
    <div class="menusor">
        <button onclick="window.location.href='index.php'">Főoldal</button>
    </div>

    <div class="tartalom">
        <div id="uzenet">
            <div id="uzenet_doboz" class="uzenet_doboz">Üzenet</div>
        </div>
        <div id="nevek">
            <div id="nevek_doboz1" class="nevek_doboz"><?php echo htmlspecialchars($j1); ?></div>
            <div id="nevek_doboz2" class="nevek_doboz"><?php echo htmlspecialchars($j2); ?></div>
        </div>
        <div id="legek">
            <div id="legek_doboz1" class="legek_doboz">Legek 1</div>
            <div id="legek_doboz2" class="legek_doboz">Legek 2</div>
        </div>
        <div id="pontok">
            <div id="pont_doboz1" class="pont_doboz">Pontok 1</div>
            <div id="pont_doboz2" class="pont_doboz">Pontok 2</div>
        </div>
        <div id="kiszallok">
            <div id="kisz_doboz1" class="kiszallok_doboz">Kiszállás 1</div>
            <div id="kisz_doboz2" class="kiszallok_doboz">Kiszállás 2</div>
        </div>
        <div id="szamok">
            <div class="doboz" id="doboz1"><button>1</button></div>
            <div class="doboz" id="doboz2"><button>2</button></div>
            <div class="doboz" id="doboz3"><button>3</button></div>
            <div class="doboz" id="doboz4"><button>4</button></div>
            <div class="doboz" id="doboz5"><button>5</button></div>
            <div class="doboz" id="doboz6"><button>6</button></div>
            <div class="doboz" id="doboz7"><button>7</button></div>
            <div class="doboz" id="doboz8"><button>8</button></div>
            <div class="doboz" id="doboz9"><button>9</button></div>
            <div class="doboz" id="doboz10"><button>&#x232B</button></div>
            <div class="doboz" id="doboz11"><button>0</button></div>
            <div class="doboz" id="doboz12"><button>&#x23CE</button></div>
        </div>
    </div>
    
    <script src="jatek.js"></script>
    <script src="heti_hatter.js"></script>
</body>
</html>