<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Darts Számoló</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Comic+Relief:wght@400;700&display=swap" rel="stylesheet">
    
    <link rel="stylesheet" href="style1.css">
    <link rel="stylesheet" href="hiba_stilus.css">
    
    <style>

        .tartalom 
      {
        font-family: Comic Relief;
        font-weight: bold;
        width: 90%;               /* nagyobb szélesség */
        max-width: 600px;        /* max méret monitoron */
        min-height: 600px;        /* nagyobb alapmagasság */
        padding: 50px;            /* tágasabb belső tér */
        font-size: 1.2rem;        /* nagyobb szöveg alapból */

        display: flex;
        flex-direction: column;
        justify-content: center;
        flex-wrap: wrap;
        gap: 5px;

        margin: 40px auto;
        background-color: rgba(255, 255, 255, 0.6);
        border-radius: 16px;
        text-align: center;
        box-shadow: 0 6px 20px rgba(0, 0, 0, 0.25);
        backdrop-filter: blur(8px);
      }


        label 
        {
            margin-top: 10px;
            font-weight: bold;
        } 

        input
        {
            padding: 8px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .reg_button
        {   font-family: Comic Relief;
            font-weight: bold;
            margin-top: 15px;
            padding: 10px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        .reg_button:hover
        {
            background-color: #0056b3;
        }

        .radio-group
        {
            display: flex;
            gap: 10px;
            margin-top: 5px;
        }

        label
        {
            margin-top: 10px;
            font-weight: bold;
        }

      @media (max-width: 768px)
      {
        .tartalom
        {
        width: 80%;
        padding: 20px;
        }
      }

      @media (max-width: 480px)
      {
        .tartalom
        {
        width: 90%;
        padding: 15px;
        }
        }

        #hiba_ablak {
      margin: 20px auto;
      max-width: 400px;
      padding: 15px;
      border-radius: 8px;
      font-weight: bold;
      text-align: center;
    }
    .ok    { background: #d4edda; color: #155724; }
    .error { background: #f8d7da; color: #721c24; }


        
    </style>

    <script>
        function validateForm() {                     
            let email = document.getElementById('email').value;
            let nickname = document.getElementById('nickname').value;
            let password = document.getElementById('password').value;
            let passwordConfirm = document.getElementById('passwordConfirm').value;
            let gender = document.querySelector('input[name="gender"]:checked');
            let birthDate = document.getElementById('birthDate').value;
            let today = new Date().toISOString().split("T")[0];

            if (!email.includes('@')) {
                hiba('Az email cím nem érvényes!');
                return false;
            }
            
            if (!nickname || !password || !passwordConfirm || !birthDate) {
                hiba('Minden mezőt ki kell tölteni!');                
                return false;
            }
            if (password !== passwordConfirm) {
                hiba('A két jelszó nem egyezik!');
                return false;
            }
            if (!gender) {
                hiba('Válasszon nemet!');
                return false;
            }
            if (birthDate >= today) {
                hiba('A születési dátumnak a mai napnál régebbinek kell lennie!');
                return false;
            }
            return true;
        }

        function checkEmail() {
            let email = document.getElementById('email').value;
            let xhr = new XMLHttpRequest();
            xhr.open('POST', 'email_check.php', true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            xhr.onreadystatechange = function () {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    if (xhr.responseText === 'foglalt') {
                        hiba('Ez az email cím már foglalt!');
                    }
                }
            };
            xhr.send('email=' + encodeURIComponent(email));
        }    
    </script> 
    
    <!--<script src="hibaablak_tool.js" defer></script> -->


</head>
<body>
    <div class="menusor">

        <?php if (isset($_SESSION["email"])): ?>
            <!-- Ha be van jelentkezve -->
            <button onclick="window.location.href='kijelentkezes.php'">Kijelentkezés</button>
        <?php else: ?>
            <!-- Ha nincs bejelentkezve -->
            <button onclick="window.location.href='bejelentkezesoldal.php'">Bejelentkezés</button>
        <?php endif; ?>
        <button onclick="window.location.href='regisztracio.php'">Regisztráció</button>
        <button onclick="window.location.href='jatek.php'">Játék!</button>
        <button onclick="window.location.href='index.php'">Főoldal</button>
        <button onclick="window.location.href='adartsrol.php'">A Dartsról</button>
        <button onclick="window.location.href='bemutatkozas.php'">Bemutatkozás</button>
    </div>



        <form class="tartalom" id="form"  onsubmit="return validateForm()" method="POST" action="regiszt.php">


        <label for="email">Email cím:</label>
        <input type="email" name="email" id="email" placeholder="Add meg az email címed!" required>
        
        <label for="nickname">Nicknév:</label>
        <input type="text" name="nickname" id="nickname" class="piros" placeholder="Adj meg egy felhasználónevet!" required>
        
        <label for="password">Jelszó:</label>
        <input type="password" name="password" id="password" placeholder="Adj meg egy jelszót!" required>
        
        <label for="passwordConfirm">Jelszó ismét:</label>
        <input type="password" name="passwordConfirm" id="passwordConfirm" placeholder="Add meg a jelszavad mégegyszer!" required>
        
        <label>Nem:</label>
        <div class="nem_valaszto">
            <input type="radio" name="gender" value="férfi"> Férfi
            <input type="radio" name="gender" value="nő"> Nő
        </div>

        <label for="birthDate">Szül<span class="zold">etési dát</span>um:</label>
        <input type="date" name="birthDate" id="birthDate">
        
        
        <button class="reg_button" type="submit">Regisztráció</button>
    </form> 

    



    
    <script src="heti_hatter.js"></script>

<script>
document.addEventListener('DOMContentLoaded', function () {
  <?php
    $regSuccess = !empty($_SESSION['reg_success']);
    $regError   = !empty($_SESSION['reg_error']) ? addslashes($_SESSION['reg_error']) : '';
    // FIGYELEM: itt még NEM törlünk!
  ?>

  const regSuccess = <?php echo $regSuccess ? 'true' : 'false'; ?>;
  const regError   = <?php echo $regError ? "'$regError'" : '""'; ?>;

  if (regSuccess) {
    alert("✅ Sikeres regisztráció!\nMost már bejelentkezhetsz.");
    window.location.href = "bejelentkezes.php";
  }

  if (regError) {
    alert("❌ " + regError);
  }
});
</script>

<?php
// Csak a JS után töröljük, hogy működjön
unset($_SESSION['reg_success'], $_SESSION['reg_error']);
?>
    
</body>
</html>