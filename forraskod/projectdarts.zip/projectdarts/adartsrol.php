<?php
session_start();
?>
<!DOCTYPE html>
<html lang="hu">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Darts Számoló</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Comic+Relief:wght@400;700&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="style1.css">

  <style>
   
    .tartalom 
      {
        width: 90%;               /* nagyobb szélesség */
        max-width: 1200px;        /* max méret monitoron */
        min-height: 600px;        /* nagyobb alapmagasság */
        padding: 50px;            /* tágasabb belső tér */
        font-size: 1.2rem;        /* nagyobb szöveg alapból */

        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        flex-wrap: wrap;
        gap: 50px;

        margin: 0 auto;
        background-color: rgba(255, 255, 255, 0.6);
        border-radius: 16px;
        text-align: center;
        box-shadow: 0 6px 20px rgba(0, 0, 0, 0.25);
        backdrop-filter: blur(8px);
      }

      @media (max-width: 768px) {
        .tartalom {
        width: 80%;
        padding: 20px;
        }
      }

      @media (max-width: 480px) {
        .tartalom {
        width: 90%;
        padding: 15px;
      }
    }

    #viewer {
      position: relative;
      max-width: 800px;
      margin: 40px auto;
    }

    #mainImage {
      max-width: 100%;
      max-height: 500px;
      border-radius: 10px;
      box-shadow: 0 0 20px rgba(0,0,0,0.2);
    }

    .arrow {
      position: absolute;
      top: 50%;
      transform: translateY(-50%);
      background: rgba(0, 0, 0, 0.5);
      color: white;
      font-size: 40px;
      padding: 10px;
      cursor: pointer;
      border-radius: 50%;
      user-select: none;
    }

    #leftArrow {
      left: 10px;
    }

    #rightArrow {
      right: 10px;
    }

    @media (max-width: 600px) {
      .arrow {
        font-size: 30px;
        padding: 8px;
      }
      #leftArrow { left: -30px; }
      #rightArrow { right: -30px; }
    }
  </style>
</head>

<body>

    <div class="menusor">

        <?php if (isset($_SESSION["email"])): ?>
            <!-- Ha be van jelentkezve -->
            <button onclick="window.location.href='kijelentkezes.php'">Kijelentkezés</button>
        <?php else: ?>
            <!-- Ha nincs bejelentkezve -->
            <button onclick="window.location.href='bejelentkezesoldal.php'">Bejelentkezés</button>
        <?php endif; ?>
        <button onclick="window.location.href='regisztracio.php'">Regisztráció</button>
        <button onclick="window.location.href='jatek.php'">Játék!</button>
        <button onclick="window.location.href='index.php'">Főoldal</button>
        <button onclick="window.location.href='adartsrol.php'">A Dartsról</button>
        <button onclick="window.location.href='bemutatkozas.php'">Bemutatkozás</button>
    </div>

  <div class="tartalom" id="viewer">
    <div id="leftArrow" class="arrow">&#8592;</div>
    <img id="mainImage" src="" alt="Fő kép">
    <div id="rightArrow" class="arrow">&#8594;</div>
  </div>

  <script>
    const images = [
      <?php
        $dir = "a_darts_kezikonyve/";
        $images = glob($dir . "*.{jpg,jpeg,png,gif}", GLOB_BRACE);
        $imageCount = count($images);
        foreach ($images as $index => $image) {
          echo json_encode($image);
          if ($index < $imageCount - 1) echo ",";
        }
      ?>
    ];

    let current = 0;
    const mainImage = document.getElementById('mainImage');
    const leftArrow = document.getElementById('leftArrow');
    const rightArrow = document.getElementById('rightArrow');

    function updateImage() {
      if (images.length > 0) {
        mainImage.src = images[current];
        mainImage.alt = "Kép " + (current + 1);
      } else {
        mainImage.alt = "Nincs kép a mappában.";
      }
    }

    leftArrow.addEventListener('click', () => {
      current = (current - 1 + images.length) % images.length;
      updateImage();
    });

    rightArrow.addEventListener('click', () => {
      current = (current + 1) % images.length;
      updateImage();
    });

    // kezdés első képpel
    updateImage();
  </script>

<script src="heti_hatter.js"></script>

</body>
</html>
